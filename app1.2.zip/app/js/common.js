$(function() {

	

});

if (window.matchMedia("(max-width: 767px)").matches) {
	/* the viewport is less than 768 pixels wide */
	
  $(document).ready(function(){
		$(function(){
			$('.cards_wrap').bxSlider({
				mode: 'fade',
				captions: true,
				controls: false,
				startSlide: 2,
				auto: true,
				stopAutoOnClick: true,
				pause: 6000,
			});
		});
	});

	

	$(document).ready(function(){
		$(function(){
			$('.services_cards_wrap').bxSlider({
				mode: 'fade',
				captions: true,
				controls: false,
				startSlide: 4,
				stopAutoOnClick: true,
				pause: 6000,
			});
		});
	});



} 

$(document).ready(function(){
	$(function(){
		$('.slider_wrap').bxSlider({
			mode: 'fade',
			captions: true,
			controls: false,
			startSlide: 1,
			auto: true,
			stopAutoOnClick: true,
			pause: 6000,
			touchEnabled: false,
		});
	});
		
});


// price



// price 1

jQuery(document).ready(function(){

	$("#price").each(function(){
		total += parseFloat(this.value);
	});

	// This button will increment the value
	$('.qtyplus').click(function(e){
		// Stop acting like a button
		e.preventDefault();
		// Get the field name
		fieldName = $(this).attr('field');
		// Get its current value
		var currentVal = parseInt($('input[name='+fieldName+']').val());
		// If is not undefined
		if (!isNaN(currentVal)) {
			// Increment
			$('input[name='+fieldName+']').val(currentVal + 1);
			qty = parseInt($('.qty').val());    
			price = parseFloat($('#price').val());
			$('#total').val((qty * price ? qty * price : 0).toFixed());
		} else {
			// Otherwise put a 0 there
			$('input[name='+fieldName+']').val();
			qty = parseInt($('.qty').val());    
			price = parseFloat($('#price').val());
			$('#total').val((qty * price ? qty * price : 0).toFixed());
		}
	});
	// This button will decrement the value till 0
	$(".qtyminus").click(function(e) {
		// Stop acting like a button
		e.preventDefault();
		// Get the field name
		fieldName = $(this).attr('field');
		// Get its current value
		var currentVal = parseInt($('input[name='+fieldName+']').val());
		// If it isn't undefined or its greater than 0
		if (!isNaN(currentVal) && currentVal > 1) {
			// Decrement one
			$('input[name='+fieldName+']').val(currentVal - 1);
			qty = parseInt($('.qty').val());    
			price = parseFloat($('#price').val());
			$('#total').val(((qty * price > 0) ? qty * price : 0).toFixed());
		} else {
			// Otherwise put a 0 there
			$('input[name='+fieldName+']').val();
			qty = parseInt($('.qty').val());    
			price = parseFloat($('#price').val());
			$('#total').val(((qty * price > 0) ? qty * price : 0).toFixed());
		}
	});
});

// price 1

// price 2

jQuery(document).ready(function(){

	$("#price2").each(function(){
		total2 += parseFloat(this.value);
	});

	// This button will increment the value
	$('.qtyplus2').click(function(e){
		// Stop acting like a button
		e.preventDefault();
		// Get the field name
		fieldName = $(this).attr('field');
		// Get its current value
		var currentVal = parseInt($('input[name='+fieldName+']').val());
		// If is not undefined
		if (!isNaN(currentVal)) {
			// Increment
			$('input[name='+fieldName+']').val(currentVal + 1);
			qty2 = parseInt($('.qty2').val());    
			price2 = parseFloat($('#price2').val());
			$('#total2').val((qty2 * price2 ? qty2 * price2 : 0).toFixed());
		} else {
			// Otherwise put a 0 there
			$('input[name='+fieldName+']').val();
			qty2 = parseInt($('.qty2').val());    
			price2 = parseFloat($('#price2').val());
			$('#total2').val((qty2 * price2 ? qty2 * price2 : 0).toFixed());
		}
	});
	// This button will decrement the value till 0
	$(".qtyminus2").click(function(e) {
		// Stop acting like a button
		e.preventDefault();
		// Get the field name
		fieldName = $(this).attr('field');
		// Get its current value
		var currentVal = parseInt($('input[name='+fieldName+']').val());
		// If it isn't undefined or its greater than 0
		if (!isNaN(currentVal) && currentVal > 1) {
			// Decrement one
			$('input[name='+fieldName+']').val(currentVal - 1);
			qty2 = parseInt($('.qty2').val());    
			price2 = parseFloat($('#price2').val());
			$('#total2').val(((qty2 * price2 > 0) ? qty2 * price2 : 0).toFixed());
		} else {
			// Otherwise put a 0 there
			$('input[name='+fieldName+']').val();
			qty2 = parseInt($('.qty2').val());    
			price2 = parseFloat($('#price2').val());
			$('#total2').val(((qty2 * price2 > 0) ? qty2 * price2 : 0).toFixed());
		}
	});
});

// price 2

// price 3

jQuery(document).ready(function(){

	$("#price3").each(function(){
		total += parseFloat(this.value);
	});

	// This button will increment the value
	$('.qtyplus3').click(function(e){
		// Stop acting like a button
		e.preventDefault();
		// Get the field name
		fieldName = $(this).attr('field');
		// Get its current value
		var currentVal = parseInt($('input[name='+fieldName+']').val());
		// If is not undefined
		if (!isNaN(currentVal)) {
			// Increment
			$('input[name='+fieldName+']').val(currentVal + 1);
			qty3 = parseInt($('.qty3').val());    
			price3 = parseFloat($('#price3').val());
			$('#total3').val((qty3 * price3 ? qty3 * price3 : 0).toFixed());
		} else {
			// Otherwise put a 0 there
			$('input[name='+fieldName+']').val();
			qty3 = parseInt($('.qty3').val());    
			price3 = parseFloat($('#price3').val());
			$('#total3').val((qty3 * price3 ? qty3 * price3 : 0).toFixed());
		}
	});
	// This button will decrement the value till 0
	$(".qtyminus3").click(function(e) {
		// Stop acting like a button
		e.preventDefault();
		// Get the field name
		fieldName = $(this).attr('field');
		// Get its current value
		var currentVal = parseInt($('input[name='+fieldName+']').val());
		// If it isn't undefined or its greater than 0
		if (!isNaN(currentVal) && currentVal > 1) {
			// Decrement one
			$('input[name='+fieldName+']').val(currentVal - 1);
			qty3 = parseInt($('.qty3').val());    
			price3 = parseFloat($('#price3').val());
			$('#total3').val(((qty3 * price3 > 0) ? qty3 * price3 : 0).toFixed());
		} else {
			// Otherwise put a 0 there
			$('input[name='+fieldName+']').val();
			qty3 = parseInt($('.qty3').val());    
			price3 = parseFloat($('#price3').val());
			$('#total3').val(((qty3 * price3 > 0) ? qty3 * price3 : 0).toFixed());
		}
	});
});

// price 3

// price 4

jQuery(document).ready(function(){

	$("#price4").each(function(){
		total += parseFloat(this.value);
	});

	// This button will increment the value
	$('.qtyplus4').click(function(e){
		// Stop acting like a button
		e.preventDefault();
		// Get the field name
		fieldName = $(this).attr('field');
		// Get its current value
		var currentVal = parseInt($('input[name='+fieldName+']').val());
		// If is not undefined
		if (!isNaN(currentVal)) {
			// Increment
			$('input[name='+fieldName+']').val(currentVal + 1);
			qty4 = parseInt($('.qty4').val());    
			price4 = parseFloat($('#price4').val());
			$('#total4').val((qty4 * price4 ? qty4 * price4 : 0).toFixed());
		} else {
			// Otherwise put a 0 there
			$('input[name='+fieldName+']').val();
			qty4 = parseInt($('.qty4').val());    
			price4 = parseFloat($('#price4').val());
			$('#total4').val((qty4 * price4 ? qty4 * price4 : 0).toFixed());
		}
	});
	// This button will decrement the value till 0
	$(".qtyminus4").click(function(e) {
		// Stop acting like a button
		e.preventDefault();
		// Get the field name
		fieldName = $(this).attr('field');
		// Get its current value
		var currentVal = parseInt($('input[name='+fieldName+']').val());
		// If it isn't undefined or its greater than 0
		if (!isNaN(currentVal) && currentVal > 1) {
			// Decrement one
			$('input[name='+fieldName+']').val(currentVal - 1);
			qty4 = parseInt($('.qty4').val());    
			price4 = parseFloat($('#price4').val());
			$('#total4').val(((qty4 * price4 > 0) ? qty4 * price4 : 0).toFixed());
		} else {
			// Otherwise put a 0 there
			$('input[name='+fieldName+']').val();
			qty4 = parseInt($('.qty4').val());    
			price4 = parseFloat($('#price4').val());
			$('#total4').val(((qty4 * price4 > 0) ? qty4 * price4 : 0).toFixed());
		}
	});
});

// price 4

// price 5

jQuery(document).ready(function(){

	$("#price5").each(function(){
		total += parseFloat(this.value);
	});

	// This button will increment the value
	$('.qtyplus5').click(function(e){
		// Stop acting like a button
		e.preventDefault();
		// Get the field name
		fieldName = $(this).attr('field');
		// Get its current value
		var currentVal = parseInt($('input[name='+fieldName+']').val());
		// If is not undefined
		if (!isNaN(currentVal)) {
			// Increment
			$('input[name='+fieldName+']').val(currentVal + 1);
			qty5 = parseInt($('.qty5').val());    
			price5 = parseFloat($('#price5').val());
			$('#total5').val((qty5 * price5 ? qty5 * price5 : 0).toFixed());
		} else {
			// Otherwise put a 0 there
			$('input[name='+fieldName+']').val();
			qty5 = parseInt($('.qty5').val());    
			price5 = parseFloat($('#price5').val());
			$('#total5').val((qty5 * price5 ? qty5 * price5 : 0).toFixed());
		}
	});
	// This button will decrement the value till 0
	$(".qtyminus5").click(function(e) {
		// Stop acting like a button
		e.preventDefault();
		// Get the field name
		fieldName = $(this).attr('field');
		// Get its current value
		var currentVal = parseInt($('input[name='+fieldName+']').val());
		// If it isn't undefined or its greater than 0
		if (!isNaN(currentVal) && currentVal > 1) {
			// Decrement one
			$('input[name='+fieldName+']').val(currentVal - 1);
			qty5 = parseInt($('.qty5').val());    
			price5 = parseFloat($('#price5').val());
			$('#total5').val(((qty5 * price5 > 0) ? qty5 * price5 : 0).toFixed());
		} else {
			// Otherwise put a 0 there
			$('input[name='+fieldName+']').val();
			qty5 = parseInt($('.qty5').val());    
			price5 = parseFloat($('#price5').val());
			$('#total5').val(((qty5 * price5 > 0) ? qty5 * price5 : 0).toFixed());
		}
	});
});

// price 5

// price 6

jQuery(document).ready(function(){

	$("#price6").each(function(){
		total += parseFloat(this.value);
	});

	// This button will increment the value
	$('.qtyplus6').click(function(e){
		// Stop acting like a button
		e.preventDefault();
		// Get the field name
		fieldName = $(this).attr('field');
		// Get its current value
		var currentVal = parseInt($('input[name='+fieldName+']').val());
		// If is not undefined
		if (!isNaN(currentVal)) {
			// Increment
			$('input[name='+fieldName+']').val(currentVal + 1);
			qty6 = parseInt($('.qty6').val());    
			price6 = parseFloat($('#price6').val());
			$('#total6').val((qty6 * price6 ? qty6 * price6 : 0).toFixed());
		} else {
			// Otherwise put a 0 there
			$('input[name='+fieldName+']').val();
			qty6 = parseInt($('.qty6').val());    
			price6 = parseFloat($('#price6').val());
			$('#total6').val((qty6 * price6 ? qty6 * price6 : 0).toFixed());
		}
	});
	// This button will decrement the value till 0
	$(".qtyminus6").click(function(e) {
		// Stop acting like a button
		e.preventDefault();
		// Get the field name
		fieldName = $(this).attr('field');
		// Get its current value
		var currentVal = parseInt($('input[name='+fieldName+']').val());
		// If it isn't undefined or its greater than 0
		if (!isNaN(currentVal) && currentVal > 1) {
			// Decrement one
			$('input[name='+fieldName+']').val(currentVal - 1);
			qty6 = parseInt($('.qty6').val());    
			price6 = parseFloat($('#price6').val());
			$('#total6').val(((qty6 * price6 > 0) ? qty6 * price6 : 0).toFixed());
		} else {
			// Otherwise put a 0 there
			$('input[name='+fieldName+']').val();
			qty6 = parseInt($('.qty6').val());    
			price6 = parseFloat($('#price6').val());
			$('#total6').val(((qty6 * price6 > 0) ? qty6 * price6 : 0).toFixed());
		}
	});
});

// price 6


// price