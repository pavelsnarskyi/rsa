if (window.matchMedia("(max-width: 767px)").matches) {
	/* the viewport is less than 768 pixels wide */
	
  $(document).ready(function(){
		$(function(){
			$('.cards_wrap').bxSlider({
				mode: 'fade',
				captions: true,
				controls: false,
				startSlide: 2,
				auto: true,
				stopAutoOnClick: true,
				pause: 6000,
			});
		});
	});

	

	$(document).ready(function(){
		$(function(){
			$('.services_cards_wrap').bxSlider({
				mode: 'fade',
				captions: true,
				controls: false,
				startSlide: 4,
				stopAutoOnClick: true,
				pause: 6000,
			});
		});
	});



} 